package com.aula118.serve;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServeApplicationTests {

	@Test
	void contextLoads() {
	}

}
